import React, { useState } from "react";
import style from "./TestModal.module.css";

export default function TestModal() {
  const [modal, setModal] = useState(false);

  function openModal() {
    setModal(true);
  }
  function closeModal() {
    setModal(false);
  }

  return (
    <div className={style["modalContainer"]}>
      <button onClick={openModal}>Open</button>
      {modal && (
        <div
          className={style.overlay}
          onClick={closeModal}
        ></div>
      )}
    </div>
  );
}
