import React from "react";

const Categories = () => {
  return (
    <div>
      <h1 style={{ height: "100vh" }}>THIS PAGE IS UNDER CONSTRUCTION</h1>
    </div>
  );
};

export default Categories;
