import React from "react";
import { useFormik } from "formik";

const SignUp = () => {
  const formik = useFormik({
    initialValues: {
      fullName: "",
      email: "",
      serviceProvided: "",
      password: "",
      confirmPassword: "",
      role: "", // "provider" or "owner"
    },
  });

  return (
    <form
      autoComplete="off"
      className="form-signup"
    >
      <div>
        <button type="button">Service Owner</button>
        <button type="button">Service Provider</button>
      </div>
      <div>
        <label htmlFor="fullName">Full Name</label>
        <input
          type="text"
          id="fullName"
          name="fullName"
          placeholder="Full Name"
          value={formik.values.fullName}
          onChange={formik.handleChange}
        />
      </div>
      <div>
        <label htmlFor="email">Email</label>
        <input
          type="email"
          id="email"
          name="email"
          placeholder="Email"
          value={formik.values.email}
          onChange={formik.handleChange}
        />
      </div>

      {/* Conditionally render additional fields based on the selected role */}
      {formik.values.role === "provider" && (
        <div>
          <label htmlFor="serviceProvided">Service Provided</label>
          <input
            type="text"
            id="serviceProvided"
            name="serviceProvided"
            placeholder="Service Provided"
            value={formik.values.serviceProvided}
            onChange={formik.handleChange}
          />
        </div>
      )}

      <div>
        <label htmlFor="password">Password</label>
        <input
          type="password"
          id="password"
          name="password"
          placeholder="Password"
          value={formik.values.password}
          onChange={formik.handleChange}
        />
      </div>
      <div>
        <label htmlFor="confirmPassword">Confirm Password</label>
        <input
          type="password"
          id="confirmPassword"
          name="confirmPassword"
          placeholder="Confirm Password"
          value={formik.values.confirmPassword}
          onChange={formik.handleChange}
        />
      </div>
      <button type="submit">Sign Up</button>
    </form>
  );
};

export default SignUp;
