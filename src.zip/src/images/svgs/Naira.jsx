import React from "react";

const Naira = () => {
  return (
    <div>
      <img src="naira.png" alt="" className="process-svg" />
    </div>
  );
};

export default Naira;
